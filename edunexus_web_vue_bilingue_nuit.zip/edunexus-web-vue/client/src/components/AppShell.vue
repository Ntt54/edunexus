<!-- EduNexus UI direction: Atelier de progression — une orientation stable, sans surcharge de navigation. -->
<script setup lang="ts">
import { computed, ref } from "vue";
import { RouterLink, RouterView } from "vue-router";
import {
  BarChart3, BookOpen, Bot, BrainCircuit, CheckSquare, Compass,
  FolderOpen, GraduationCap, House, LibraryBig, Settings2, Sparkles,
} from "lucide-vue-next";
import { useLearningStore } from "@/stores/learning";
import NexusFlow from "@/components/NexusFlow.vue";
import PreferenceControls from "@/components/PreferenceControls.vue";
import { usePreferences } from "@/stores/preferences";

const { state, dismissNotice } = useLearningStore();
const subjectLabel = computed(() => state.data?.subject.name ?? t("app.loadingSubject"));
const brandMark = "/manus-storage/edunexus-nexus-mark_e91945cc.png";
const markUnavailable = ref(false);
const { t } = usePreferences();

const groups = [
  { label: "Commencer", items: [
    { labelKey: "nav.home", to: "/", icon: House },
    { labelKey: "nav.path", to: "/parcours", icon: Compass },
    { labelKey: "nav.revise", to: "/reviser", icon: BrainCircuit },
  ] },
  { label: "S’entraîner", items: [
    { labelKey: "nav.practice", to: "/exercices", icon: CheckSquare },
    { labelKey: "nav.quiz", to: "/quiz", icon: GraduationCap },
    { labelKey: "nav.progress", to: "/progression", icon: BarChart3 },
  ] },
  { label: "Explorer", items: [
    { labelKey: "nav.tutor", to: "/tuteur", icon: Bot },
    { labelKey: "nav.sources", to: "/sources", icon: LibraryBig },
  ] },
  { label: "Espace", items: [
    { labelKey: "nav.settings", to: "/reglages", icon: Settings2 },
  ] },
];
</script>

<template>
  <div class="app-shell">
    <aside class="sidebar" aria-label="Navigation principale">
      <RouterLink class="brand" to="/" aria-label="EduNexus">
        <img v-if="!markUnavailable" :src="brandMark" alt="" aria-hidden="true" @error="markUnavailable = true" />
        <span v-else class="brand-mark-fallback" aria-hidden="true"><i></i><i></i><i></i></span>
        <span>Edu<span>Nexus</span></span>
      </RouterLink>

      <div class="matter-switcher" aria-label="Matière active">
        <span class="eyebrow">{{ t('app.workshop') }}</span>
        <strong>{{ subjectLabel }}</strong>
        <small>{{ t('app.localData') }}</small>
      </div>

      <nav class="main-nav">
        <section v-for="group in groups" :key="group.label" class="nav-group" :aria-label="t(`nav.${group.label === 'Commencer' ? 'start' : group.label === 'S’entraîner' ? 'train' : group.label === 'Explorer' ? 'explore' : 'space'}`)">
          <p>{{ t(`nav.${group.label === 'Commencer' ? 'start' : group.label === 'S’entraîner' ? 'train' : group.label === 'Explorer' ? 'explore' : 'space'}`) }}</p>
          <RouterLink v-for="item in group.items" :key="item.to" :to="item.to" class="nav-item">
            <component :is="item.icon" :size="18" stroke-width="2" aria-hidden="true" />
            <span>{{ t(item.labelKey) }}</span>
          </RouterLink>
        </section>
      </nav>

      <div class="sidebar-foot">
        <BookOpen :size="17" aria-hidden="true" />
        <span>{{ t('app.localData') }}</span>
      </div>
    </aside>

    <section class="workspace">
      <header class="topbar">
        <div class="topbar-context">
          <span class="eyebrow">{{ t('app.workshop') }}</span>
          <span class="topbar-status"><i></i> {{ t('app.sourcesReady') }}</span>
        </div>
        <div class="topbar-tools">
          <span class="engine-chip"><Sparkles :size="15" aria-hidden="true" /> {{ t('app.localModel') }}</span>
          <RouterLink to="/sources" class="quiet-link"><FolderOpen :size="16" aria-hidden="true" /> {{ t('app.sources') }}</RouterLink>
          <PreferenceControls />
        </div>
      </header>
      <NexusFlow />
      <main class="page-frame" tabindex="-1">
        <RouterView />
      </main>
    </section>

    <Transition name="toast">
      <div v-if="state.notice" class="toast" role="status" aria-live="polite">
        <span>{{ state.notice }}</span>
        <button type="button" aria-label="Fermer le message" @click="dismissNotice">Fermer</button>
      </div>
    </Transition>
  </div>
</template>
