export type ActivityType = "concept" | "reading" | "exercise" | "quiz" | "flashcard_review";
export type StepStatus = "pending" | "completed";
export type MasteryState = "à revoir" | "en cours" | "maîtrisé";

export interface Subject { id: string; name: string; level: string; }

export interface LearningStep {
  id: string;
  title: string;
  activityType: ActivityType;
  duration: number;
  status: StepStatus;
  source: string;
}

export interface LearningPath {
  id: string;
  title: string;
  description: string;
  progress: number;
  status: "active" | "draft" | "completed";
  steps: LearningStep[];
}

export interface ConceptProgress {
  id: string;
  name: string;
  score: number;
  recentFailures: number;
  nextReview?: string;
}

export interface ReviewItem { id: string; concept: string; due: string; source: string; }

export interface SourceBook {
  id: string;
  title: string;
  chapter: string;
  status: "indexed" | "indexing" | "pending" | "error";
  updatedAt: string;
  sourceType: "PDF" | "EPUB" | "Note";
}

export interface QueueState {
  running: boolean;
  currentBookTitle?: string;
  pendingCount: number;
  completedCount: number;
}

export interface DashboardData {
  subject: Subject;
  path: LearningPath;
  concepts: ConceptProgress[];
  reviews: ReviewItem[];
  books: SourceBook[];
  queue: QueueState;
}
