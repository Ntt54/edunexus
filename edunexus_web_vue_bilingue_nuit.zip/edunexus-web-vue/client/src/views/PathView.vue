<!-- EduNexus UI direction: Atelier de progression — une frise lisible qui rend l’étape actuelle immédiatement identifiable. -->
<script setup lang="ts">
import { computed } from "vue";
import { ArrowRight, Check, CheckCircle2, Circle, Clock3, FileText, HelpCircle, Lightbulb, Play, RotateCcw } from "lucide-vue-next";
import ProgressRing from "@/components/ProgressRing.vue";
import StatusPill from "@/components/StatusPill.vue";
import { useLearningStore } from "@/stores/learning";
import type { ActivityType } from "@/types";
import { usePreferences } from "@/stores/preferences";

const { state, nextStep, completeStep } = useLearningStore();
const { t } = usePreferences();
const path = computed(() => state.data?.path);
const iconFor: Record<ActivityType, typeof FileText> = { concept: Lightbulb, reading: FileText, exercise: Play, quiz: HelpCircle, flashcard_review: RotateCcw };
const labelFor = (activityType: ActivityType) => t(`activity.${activityType}`);
</script>

<template>
  <section v-if="path" class="page path-page">
    <header class="page-intro path-intro"><div><p class="eyebrow">{{ t('path.kicker') }}</p><h1>{{ path.title }}</h1><p>{{ path.description }}</p></div><ProgressRing :value="path.progress" :size="104" /></header>
    <section class="path-layout">
      <aside class="path-summary content-panel"><p class="eyebrow">{{ t('path.reference') }}</p><h2>{{ t('path.complete', { percent: path.progress }) }}</h2><p>{{ t('path.validated', { count: path.steps.filter((item) => item.status === 'completed').length, total: path.steps.length }) }}</p><div class="source-proof"><FileText :size="18" aria-hidden="true" /><span>{{ t('path.linked') }}</span></div></aside>
      <section class="timeline-panel content-panel"><div class="panel-heading"><div><p class="eyebrow">{{ t('path.steps') }}</p><h2>{{ t('path.continue') }}</h2></div><StatusPill tone="indigo">{{ t('status.current') }}</StatusPill></div>
        <ol class="learning-timeline">
          <li v-for="(step, index) in path.steps" :key="step.id" :class="{ completed: step.status === 'completed', current: step.id === nextStep?.id }">
            <div class="timeline-node"><Check v-if="step.status === 'completed'" :size="16" aria-hidden="true" /><Circle v-else :size="16" aria-hidden="true" /></div>
            <article class="step-card"><div class="step-card-head"><div class="step-type"><component :is="iconFor[step.activityType]" :size="16" aria-hidden="true" />{{ labelFor(step.activityType) }}</div><StatusPill v-if="step.id === nextStep?.id" tone="orange">{{ t('status.toDo') }}</StatusPill><StatusPill v-else-if="step.status === 'completed'" tone="green">{{ t('status.completed') }}</StatusPill></div><h3><span>{{ index + 1 }}.</span>{{ step.title }}</h3><p><Clock3 :size="15" aria-hidden="true" /> {{ t('dashboard.approx', { minutes: step.duration }) }} <i></i> {{ step.source }}</p><div v-if="step.id === nextStep?.id" class="step-actions"><RouterLink :to="step.activityType === 'exercise' ? '/exercices' : step.activityType === 'quiz' ? '/quiz' : '/reviser'" class="primary-action">{{ t('path.open') }} <ArrowRight :size="17" /></RouterLink><button type="button" class="text-button" @click="completeStep(step.id)">{{ t('path.markComplete') }}</button></div></article>
          </li>
        </ol>
      </section>
    </section>
  </section>
</template>
