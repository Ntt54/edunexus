<!-- EduNexus UI direction: Atelier de progression — les réglages sont regroupés par décision, avec un effet compréhensible. -->
<script setup lang="ts">
import { ref } from "vue";
import { Check, Cpu, Database, Moon, ShieldCheck } from "lucide-vue-next";
import { usePreferences } from "@/stores/preferences";

const nightly = ref(true);
const preparation = ref(true);
const saved = ref(false);
const { t } = usePreferences();
</script>

<template>
  <section class="page settings-page"><header class="page-intro"><div><p class="eyebrow">{{ t('settings.kicker') }}</p><h1>{{ t('settings.title') }}</h1><p>{{ t('settings.copy') }}</p></div></header><section class="settings-layout"><article class="content-panel settings-form"><div class="settings-section"><div class="settings-icon"><Cpu :size="20" aria-hidden="true" /></div><div><p class="eyebrow">{{ t('settings.resources') }}</p><h2>{{ t('settings.models') }}</h2><p>{{ t('settings.modelsCopy') }}</p></div><div class="form-grid"><label>{{ t('settings.batch') }}<input type="number" value="16" min="1" max="128" /></label><label>{{ t('settings.concurrency') }}<input type="number" value="1" min="1" max="4" /></label></div></div><div class="settings-section"><div class="settings-icon"><Moon :size="20" aria-hidden="true" /></div><div><p class="eyebrow">{{ t('settings.automation') }}</p><h2>{{ t('settings.night') }}</h2><p>{{ t('settings.nightCopy') }}</p></div><label class="toggle-row"><span><strong>{{ t('settings.nightWindow') }}</strong><small>{{ t('settings.nightWindowCopy') }}</small></span><input v-model="nightly" type="checkbox" /></label><label class="toggle-row"><span><strong>{{ t('settings.prepare') }}</strong><small>{{ t('settings.prepareCopy') }}</small></span><input v-model="preparation" type="checkbox" /></label></div><div class="settings-section"><div class="settings-icon"><Database :size="20" aria-hidden="true" /></div><div><p class="eyebrow">{{ t('settings.maintenance') }}</p><h2>{{ t('settings.library') }}</h2><p>{{ t('settings.libraryCopy') }}</p></div><button type="button" class="secondary-action">{{ t('settings.run') }}</button></div><button type="button" class="primary-action save-button" @click="saved = true"><Check :size="17" aria-hidden="true" />{{ saved ? t('settings.saved') : t('settings.save') }}</button></article><aside class="settings-aside"><article class="content-panel"><ShieldCheck :size="22" aria-hidden="true" /><p class="eyebrow">{{ t('settings.privacy') }}</p><h2>{{ t('settings.local') }}</h2><p>{{ t('settings.localCopy') }}</p></article></aside></section></section>
</template>
