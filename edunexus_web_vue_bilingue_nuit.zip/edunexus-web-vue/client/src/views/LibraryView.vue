<!-- EduNexus UI direction: Atelier de progression — les sources sont des preuves visibles, pas un stockage opaque. -->
<script setup lang="ts">
import { computed } from "vue";
import { ArrowRight, FileText, FolderPlus, LoaderCircle, Pause, Play, Search, ShieldCheck } from "lucide-vue-next";
import StatusPill from "@/components/StatusPill.vue";
import { useLearningStore } from "@/stores/learning";
import { usePreferences } from "@/stores/preferences";

const { state, toggleQueue } = useLearningStore();
const { t } = usePreferences();
const data = computed(() => state.data);
const sourceMap = "/manus-storage/edunexus-source-map_9e5b5e0d.png";
const tone = (status: string) => status === "indexed" ? "green" : status === "indexing" ? "indigo" : status === "error" ? "orange" : "slate";
const label = (status: string) => ({ indexed: t('status.ready'), indexing: t('status.indexing'), pending: t('status.queued'), error: t('status.review') }[status] ?? status);
</script>

<template>
  <section v-if="data" class="page library-page"><header class="page-intro library-intro"><div><p class="eyebrow">{{ t('library.kicker') }}</p><h1>{{ t('library.title') }}</h1><p>{{ t('library.copy') }}</p></div><img :src="sourceMap" :alt="t('library.title')" @error="($event.currentTarget as HTMLImageElement).style.display = 'none'" /></header>
    <section class="library-toolbar content-panel"><div class="search-field"><Search :size="18" aria-hidden="true" /><input type="search" :placeholder="t('library.search')" :aria-label="t('library.search')" /></div><button type="button" class="primary-action"><FolderPlus :size="18" aria-hidden="true" /> {{ t('library.add') }}</button></section>
    <section class="queue-banner" :class="{ running: data.queue.running }"><div><div class="queue-state"><span></span>{{ data.queue.running ? t('library.queueWorking') : t('library.queueReady') }}</div><strong>{{ data.queue.running ? data.queue.currentBookTitle ?? t('library.current') : t('library.waiting', { count: data.queue.pendingCount }) }}</strong><p>{{ t('library.queueReason', { count: data.queue.completedCount }) }}</p></div><button type="button" class="secondary-action" @click="toggleQueue"><Pause v-if="data.queue.running" :size="17" aria-hidden="true" /><Play v-else :size="17" aria-hidden="true" />{{ data.queue.running ? t('library.pause') : t('library.start') }}</button></section>
    <section class="source-list content-panel"><div class="panel-heading"><div><p class="eyebrow">{{ t('library.active') }}</p><h2>{{ t('library.documents', { count: data.books.length }) }}</h2></div><span class="source-hint"><ShieldCheck :size="16" aria-hidden="true" /> {{ t('library.provenance') }}</span></div><article v-for="book in data.books" :key="book.id" class="source-row"><div class="source-icon"><FileText :size="20" aria-hidden="true" /></div><div class="source-copy"><strong>{{ book.title }}</strong><span>{{ book.sourceType }} · {{ book.chapter }} · {{ book.updatedAt }}</span></div><StatusPill :tone="tone(book.status) as any">{{ label(book.status) }}</StatusPill><button type="button" class="row-action" :aria-label="book.title"><ArrowRight :size="18" aria-hidden="true" /></button></article></section>
  </section>
</template>
