<!-- EduNexus UI direction: Atelier de progression — le tuteur garde les sources et le contexte de l’apprenant visibles. -->
<script setup lang="ts">
import { computed, ref } from "vue";
import { ArrowUp, BookOpenCheck, Quote } from "lucide-vue-next";
import { useLearningStore } from "@/stores/learning";
import { usePreferences } from "@/stores/preferences";

const { state } = useLearningStore();
const { t } = usePreferences();
const prompt = ref("");
const sent = ref(false);
const subject = computed(() => state.data?.subject.name ?? t("tutor.defaultSubject"));
</script>

<template>
  <section class="page tutor-page"><header class="page-intro"><div><p class="eyebrow">{{ t('tutor.kicker') }}</p><h1>{{ t('tutor.title') }}</h1><p>{{ t('tutor.copy') }}</p></div></header><section class="tutor-layout"><article class="chat-shell content-panel"><div class="chat-context"><BookOpenCheck :size="19" aria-hidden="true" /><span><strong>{{ subject }}</strong><small>{{ t('tutor.limited') }}</small></span></div><div class="chat-empty"><div class="bot-mark"><Quote :size="22" aria-hidden="true" /></div><h2>{{ t('tutor.question') }}</h2><p>{{ t('tutor.questionCopy') }}</p><div class="prompt-suggestions"><button type="button" @click="prompt = t('tutor.explain')">{{ t('tutor.explain') }}</button><button type="button" @click="prompt = t('tutor.ask')">{{ t('tutor.ask') }}</button></div><div v-if="sent" class="integration-note"><strong>{{ t('tutor.messageReady') }}</strong> {{ t('tutor.messageCopy') }}</div></div><form class="chat-input" @submit.prevent="sent = Boolean(prompt.trim())"><textarea v-model="prompt" rows="2" :placeholder="t('tutor.placeholder')" :aria-label="t('tutor.placeholder')" /><button type="submit" :disabled="!prompt.trim()" :aria-label="t('tutor.question')"><ArrowUp :size="19" aria-hidden="true" /></button></form></article><aside class="tutor-side"><article class="content-panel"><p class="eyebrow">{{ t('tutor.tip') }}</p><h2>{{ t('tutor.askCitation') }}</h2><p>{{ t('tutor.citationReason') }}</p></article><article class="content-panel"><p class="eyebrow">{{ t('tutor.mode') }}</p><h2>{{ t('tutor.hint') }}</h2><p>{{ t('tutor.hintReason') }}</p></article></aside></section></section>
</template>
