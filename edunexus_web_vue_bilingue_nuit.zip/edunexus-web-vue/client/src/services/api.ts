import { demoDashboard } from "@/data/demo";
import type { DashboardData, LearningPath, QueueState, SourceBook } from "@/types";

const apiBase = import.meta.env.VITE_EDUNEXUS_API_BASE ?? "/api/tutor";
const demoMode = import.meta.env.VITE_EDUNEXUS_DEMO_MODE !== "false";

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${apiBase}${path}`, {
    headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) },
    ...init,
  });
  if (!response.ok) throw new Error(`Erreur API ${response.status}`);
  return response.json() as Promise<T>;
}

/** Mapping volontairement isolé : OpenCode pourra adapter ces fonctions aux contrats FastAPI définitifs. */
export const tutorApi = {
  async dashboard(): Promise<DashboardData> {
    if (demoMode) return structuredClone(demoDashboard);
    const subjects = await request<{ subjects: Array<{ id: string; name: string }> }>("/subjects");
    const subject = subjects.subjects[0];
    if (!subject) throw new Error("Aucune matière disponible");
    const [paths, progress, reviews, books, queue] = await Promise.all([
      request<{ paths: LearningPath[] }>(`/paths?subject_id=${encodeURIComponent(subject.id)}`),
      request<{ progress: DashboardData["concepts"] }>(`/subjects/${subject.id}/progress`),
      request<{ due: DashboardData["reviews"] }>(`/subjects/${subject.id}/reviews/due`),
      request<{ books: SourceBook[] }>("/books"),
      request<QueueState>("/index-queue"),
    ]);
    const path = paths.paths.find((item) => item.status === "active") ?? paths.paths[0];
    if (!path) throw new Error("Aucun parcours disponible");
    return { subject: { ...subject, level: "À définir" }, path, concepts: progress.progress, reviews: reviews.due, books: books.books, queue };
  },
  async setQueue(running: boolean): Promise<QueueState> {
    if (demoMode) return { ...demoDashboard.queue, running };
    return request<QueueState>(`/index-queue/${running ? "start" : "stop"}`, { method: "POST" });
  },
  async completeStep(pathId: string, stepId: string): Promise<void> {
    if (demoMode) return;
    await request(`/paths/${pathId}/steps/${stepId}`, { method: "PUT", body: JSON.stringify({ status: "completed" }) });
  },
};
