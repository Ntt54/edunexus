import type { DashboardData } from "@/types";

export const demoDashboard: DashboardData = {
  subject: { id: "java", name: "Programmation Java", level: "Débutant" },
  path: {
    id: "java-foundations",
    title: "Fondamentaux Java",
    description: "Des variables aux premières structures de contrôle, à partir de vos ouvrages importés.",
    progress: 42,
    status: "active",
    steps: [
      { id: "java-1", title: "Lire : variables et types", activityType: "reading", duration: 10, status: "completed", source: "Java — chap. 2" },
      { id: "java-2", title: "Comprendre les conditions", activityType: "concept", duration: 12, status: "completed", source: "Java — chap. 3" },
      { id: "java-3", title: "Écrire votre premier if / else", activityType: "exercise", duration: 15, status: "pending", source: "Java — chap. 3" },
      { id: "java-4", title: "Quiz : décisions et opérateurs", activityType: "quiz", duration: 8, status: "pending", source: "Java — chap. 3" },
      { id: "java-5", title: "Réviser les boucles", activityType: "flashcard_review", duration: 8, status: "pending", source: "Java — chap. 4" },
    ],
  },
  concepts: [
    { id: "variables", name: "Variables et types", score: 84, recentFailures: 0, nextReview: "dans 4 jours" },
    { id: "conditions", name: "Conditions", score: 67, recentFailures: 1, nextReview: "demain" },
    { id: "loops", name: "Boucles", score: 38, recentFailures: 3, nextReview: "aujourd’hui" },
    { id: "methods", name: "Méthodes", score: 15, recentFailures: 0 },
  ],
  reviews: [
    { id: "r1", concept: "Boucles", due: "Aujourd’hui", source: "Java — chap. 4" },
    { id: "r2", concept: "Conditions", due: "Demain", source: "Java — chap. 3" },
  ],
  books: [
    { id: "b1", title: "Java — apprendre à programmer", chapter: "Chap. 3 · Conditions", status: "indexed", updatedAt: "il y a 2 h", sourceType: "PDF" },
    { id: "b2", title: "Exercices Java progressifs", chapter: "Chap. 1 · Variables", status: "indexed", updatedAt: "hier", sourceType: "EPUB" },
    { id: "b3", title: "Plan de cours personnel", chapter: "Objectifs du trimestre", status: "pending", updatedAt: "aujourd’hui", sourceType: "Note" },
  ],
  queue: { running: false, pendingCount: 1, completedCount: 2 },
};
